package com.vandana.example.activity;

import android.app.SearchManager;
import android.content.Intent;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;


import com.vandana.example.fragment.GalleryImageFragment;
import com.vandana.example.R;
import com.vandana.example.urldefinitions.UrlManager;

public class GalleryImageActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public static int buffersize=50;
    private static final String TAG = GalleryImageActivity.class.getSimpleName();
    public Spinner spinner;
    private static final String[] paths = {"50","100","200"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_image);
        spinner = (Spinner)findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(GalleryImageActivity.this,
                android.R.layout.simple_spinner_item,paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    //get the spinner from the xml.
    //Spinner dropdown = (Spinner) findViewById(R.id.spinner1);
    //create a list of items for the spinner.
    //String[] items = new String[]{"1", "2", "three"};

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            Log.d(TAG, "Received a new search query: " + query);

            PreferenceManager.getDefaultSharedPreferences(this)
                    .edit()
                    .putString(UrlManager.PREF_SEARCH_QUERY, query)
                    .commit();
            FragmentManager fm = getSupportFragmentManager();
            Fragment fragment = fm.findFragmentById(R.id.gallery_fragment);
            if (fragment != null) {
                ((GalleryImageFragment) fragment).refresh();
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        switch (i) {
            case 0:
                // Whatever you want to happen when the first item gets selected
                buffersize=50;
                Toast toast = Toast.makeText(getApplicationContext(), "50 images are getting loaded at once", Toast.LENGTH_SHORT); toast.show();
                Log.d(TAG, "50\n " );
                break;
            case 1:
                // Whatever you want to happen when the second item gets selected
                buffersize=100;
                toast = Toast.makeText(getApplicationContext(), "100 images are getting loaded at once", Toast.LENGTH_SHORT);
                toast.show();
                Log.d(TAG, "100\n " );
                break;
            case 2:
                // Whatever you want to happen when the thrid item gets selected
                buffersize=200;
                toast = Toast.makeText(getApplicationContext(), "200 images are getting loaded at once", Toast.LENGTH_SHORT); toast.show();
                Log.d(TAG, "200\n " );
                break;

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    public static int getBufferSize()
    {
        return (buffersize);
    }
}
