package com.vandana.example.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.vandana.example.R;
import com.vandana.example.imageobjects.GalleryImageItem;
import com.bumptech.glide.Glide;

/**
 * A simple {@link Fragment} subclass.
 */
public class ImageFragment extends Fragment {

    public static final String TAG = ImageFragment.class.getSimpleName();

    private GalleryImageItem mGalleryImageItem;
    private ImageView mImageView;

    public ImageFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_image, container, false);
        mGalleryImageItem = (GalleryImageItem) getActivity().getIntent().getSerializableExtra("item");
        mImageView = (ImageView) view.findViewById(R.id.photo);
        Glide.with(this).load(mGalleryImageItem.getUrl()).thumbnail(0.5f).into(mImageView);
        return view;
    }

}
